﻿namespace DoWhile_While
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<long> userNum = new();
            long i;
            string? userNumInpt = Console.ReadLine();
            while (true)
            {
                Console.WriteLine("input num");
                Console.Write("> ");

                while (!Int64.TryParse(userNumInpt, out i))
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                    userNumInpt = Console.ReadLine();
                }

                userNum.Add(i);
                Console.WriteLine(userNum.Average());
                Console.ReadLine();
            }

        }
    }
}
﻿namespace PolymorphismForm
{
    partial class frmVoidMethods
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVoidMethods));
            txtOrderInput = new TextBox();
            toolTipOrderInput = new ToolTip(components);
            txtTotalOrder = new TextBox();
            txtTotalCost = new TextBox();
            btnSearchAllRecords = new Button();
            btnFindOrder = new Button();
            lstOrderDetails = new ListView();
            clmnOrderNum = new ColumnHeader();
            clmnCustomerName = new ColumnHeader();
            clmnSubtotal = new ColumnHeader();
            clmnVAT = new ColumnHeader();
            clmnTotal = new ColumnHeader();
            label1 = new Label();
            btnTotalCost = new Button();
            SuspendLayout();
            // 
            // txtOrderInput
            // 
            txtOrderInput.BackColor = Color.FromArgb(40, 40, 40);
            txtOrderInput.BorderStyle = BorderStyle.None;
            txtOrderInput.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtOrderInput.ForeColor = Color.White;
            txtOrderInput.Location = new Point(12, 67);
            txtOrderInput.Multiline = true;
            txtOrderInput.Name = "txtOrderInput";
            txtOrderInput.Size = new Size(460, 20);
            txtOrderInput.TabIndex = 1;
            toolTipOrderInput.SetToolTip(txtOrderInput, "Please enter your order number\r\n");
            txtOrderInput.TextChanged += textBox1_TextChanged;
            // 
            // txtTotalOrder
            // 
            txtTotalOrder.BackColor = Color.FromArgb(40, 40, 40);
            txtTotalOrder.BorderStyle = BorderStyle.None;
            txtTotalOrder.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtTotalOrder.ForeColor = Color.White;
            txtTotalOrder.Location = new Point(12, 93);
            txtTotalOrder.Multiline = true;
            txtTotalOrder.Name = "txtTotalOrder";
            txtTotalOrder.ReadOnly = true;
            txtTotalOrder.Size = new Size(460, 20);
            txtTotalOrder.TabIndex = 5;
            toolTipOrderInput.SetToolTip(txtTotalOrder, "Total number of orders");
            txtTotalOrder.TextChanged += txtTotalOrder_TextChanged;
            // 
            // txtTotalCost
            // 
            txtTotalCost.BackColor = Color.FromArgb(40, 40, 40);
            txtTotalCost.BorderStyle = BorderStyle.None;
            txtTotalCost.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtTotalCost.ForeColor = Color.White;
            txtTotalCost.Location = new Point(12, 119);
            txtTotalCost.Multiline = true;
            txtTotalCost.Name = "txtTotalCost";
            txtTotalCost.ReadOnly = true;
            txtTotalCost.Size = new Size(460, 20);
            txtTotalCost.TabIndex = 6;
            toolTipOrderInput.SetToolTip(txtTotalCost, "Total cost of orders");
            txtTotalCost.TextChanged += textBox1_TextChanged_1;
            // 
            // btnSearchAllRecords
            // 
            btnSearchAllRecords.BackColor = Color.FromArgb(40, 40, 40);
            btnSearchAllRecords.BackgroundImageLayout = ImageLayout.None;
            btnSearchAllRecords.FlatAppearance.BorderSize = 0;
            btnSearchAllRecords.FlatStyle = FlatStyle.Flat;
            btnSearchAllRecords.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearchAllRecords.ForeColor = Color.White;
            btnSearchAllRecords.Location = new Point(12, 145);
            btnSearchAllRecords.Name = "btnSearchAllRecords";
            btnSearchAllRecords.Size = new Size(155, 42);
            btnSearchAllRecords.TabIndex = 2;
            btnSearchAllRecords.Text = "Show All Records";
            btnSearchAllRecords.UseVisualStyleBackColor = false;
            btnSearchAllRecords.Click += btnSearchAllRecords_Click;
            // 
            // btnFindOrder
            // 
            btnFindOrder.BackColor = Color.FromArgb(40, 40, 40);
            btnFindOrder.BackgroundImageLayout = ImageLayout.None;
            btnFindOrder.FlatAppearance.BorderSize = 0;
            btnFindOrder.FlatStyle = FlatStyle.Flat;
            btnFindOrder.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnFindOrder.ForeColor = Color.White;
            btnFindOrder.Location = new Point(318, 145);
            btnFindOrder.Name = "btnFindOrder";
            btnFindOrder.Size = new Size(155, 42);
            btnFindOrder.TabIndex = 3;
            btnFindOrder.Text = "Find Order Details\r\n";
            btnFindOrder.UseVisualStyleBackColor = false;
            btnFindOrder.Click += button2_Click;
            // 
            // lstOrderDetails
            // 
            lstOrderDetails.BackColor = Color.FromArgb(40, 40, 40);
            lstOrderDetails.BorderStyle = BorderStyle.None;
            lstOrderDetails.Columns.AddRange(new ColumnHeader[] { clmnOrderNum, clmnCustomerName, clmnSubtotal, clmnVAT, clmnTotal });
            lstOrderDetails.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            lstOrderDetails.ForeColor = Color.White;
            lstOrderDetails.GridLines = true;
            lstOrderDetails.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            lstOrderDetails.Location = new Point(12, 193);
            lstOrderDetails.Name = "lstOrderDetails";
            lstOrderDetails.Size = new Size(460, 334);
            lstOrderDetails.TabIndex = 4;
            lstOrderDetails.UseCompatibleStateImageBehavior = false;
            lstOrderDetails.View = View.Details;
            lstOrderDetails.SelectedIndexChanged += lstOrderDetails_SelectedIndexChanged;
            // 
            // clmnOrderNum
            // 
            clmnOrderNum.Text = "Order Number";
            clmnOrderNum.Width = 140;
            // 
            // clmnCustomerName
            // 
            clmnCustomerName.Text = "Customer Name";
            clmnCustomerName.Width = 140;
            // 
            // clmnSubtotal
            // 
            clmnSubtotal.Text = "Subtotal";
            // 
            // clmnVAT
            // 
            clmnVAT.Text = "VAT";
            // 
            // clmnTotal
            // 
            clmnTotal.Text = "Total";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Bahnschrift", 36F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(2, 9);
            label1.Name = "label1";
            label1.Size = new Size(394, 58);
            label1.TabIndex = 0;
            label1.Text = "Gerry Fine Foods";
            label1.Click += label1_Click;
            // 
            // btnTotalCost
            // 
            btnTotalCost.BackColor = Color.FromArgb(40, 40, 40);
            btnTotalCost.BackgroundImageLayout = ImageLayout.None;
            btnTotalCost.FlatAppearance.BorderSize = 0;
            btnTotalCost.FlatStyle = FlatStyle.Flat;
            btnTotalCost.Font = new Font("Bahnschrift", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnTotalCost.ForeColor = Color.White;
            btnTotalCost.Location = new Point(173, 145);
            btnTotalCost.Name = "btnTotalCost";
            btnTotalCost.Size = new Size(139, 42);
            btnTotalCost.TabIndex = 7;
            btnTotalCost.Text = "Total Cost\r\n";
            btnTotalCost.UseVisualStyleBackColor = false;
            btnTotalCost.Click += button1_Click;
            // 
            // frmVoidMethods
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(32, 32, 32);
            ClientSize = new Size(484, 539);
            Controls.Add(btnTotalCost);
            Controls.Add(txtTotalCost);
            Controls.Add(txtTotalOrder);
            Controls.Add(lstOrderDetails);
            Controls.Add(btnFindOrder);
            Controls.Add(btnSearchAllRecords);
            Controls.Add(txtOrderInput);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "frmVoidMethods";
            Text = "Void Methods";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtOrderInput;
        private ToolTip toolTipOrderInput;
        private Button btnSearchAllRecords;
        private Button btnFindOrder;
        private ListView lstOrderDetails;
        private ColumnHeader clmnOrderNum;
        private ColumnHeader clmnCustomerName;
        private ColumnHeader clmnSubtotal;
        private ColumnHeader clmnVAT;
        private ColumnHeader clmnTotal;
        private Label label1;
        private TextBox txtTotalOrder;
        private TextBox txtTotalCost;
        private Button btnTotalCost;
    }
}
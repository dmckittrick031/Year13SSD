﻿namespace InsertionSort
{
    internal class Program
    {
        static List<long> InsertionSort(List<long> toSort)
        {
            for (int i = 0; i < toSort.Count - 1; i++)
            {
                for (int k = i + 1; k > 0; k--)
                {
                    if (toSort[k - 1] > toSort[k])
                    {
                        (toSort[k - 1], toSort[k]) = (toSort[k], toSort[k - 1]);
                    }
                }
            }
            return toSort;
        }
        static void Main()
        {
            List<long> numList = new();
            long sntNum;
            long sntLength;

            Console.WriteLine("How many elements would you like to enter?: ");
            Console.Write("> ");
            string? userLength = Console.ReadLine();
            Console.Clear();

            while (!Int64.TryParse(userLength, out sntLength))
            {
                Console.Clear();
                Console.WriteLine("Please try again. Only input a number: ");
                Console.Write("> ");
                userLength = Console.ReadLine();
            }


            for (int i = 0; i < sntLength; i++)
            {
                Console.Clear();
                Console.WriteLine("Please enter a number: ");
                Console.Write("> ");
                string? userNum = Console.ReadLine();

                while (!Int64.TryParse(userNum, out sntNum))
                {
                    Console.Clear();
                    Console.WriteLine("Please try again. Only input a number: ");
                    Console.Write("> ");
                    userNum = Console.ReadLine();   
                }

                numList.Add(sntNum);
            }

            Console.Clear();
            Console.WriteLine("Original List:");
            Console.WriteLine(string.Join(", ", numList));

            Console.WriteLine("Sorted List:");
            InsertionSort(numList);
            Console.WriteLine(string.Join(", ", numList));

            Console.ReadLine();
        }
    }
}
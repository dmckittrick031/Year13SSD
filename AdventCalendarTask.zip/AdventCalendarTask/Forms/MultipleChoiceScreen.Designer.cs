﻿namespace AdventCalendarTask.Forms
{
    partial class MultipleChoiceScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblQuestion = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            rbtnAns4 = new AdventForm.RoundedButton();
            rbtnAns3 = new AdventForm.RoundedButton();
            rbtnAns2 = new AdventForm.RoundedButton();
            rbtnAns1 = new AdventForm.RoundedButton();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblQuestion
            // 
            lblQuestion.AutoSize = true;
            lblQuestion.BackColor = Color.Transparent;
            lblQuestion.Dock = DockStyle.Left;
            lblQuestion.Font = new Font("Bahnschrift", 30F, FontStyle.Regular, GraphicsUnit.Point);
            lblQuestion.ForeColor = Color.White;
            lblQuestion.Location = new Point(0, 0);
            lblQuestion.Name = "lblQuestion";
            lblQuestion.Padding = new Padding(10);
            lblQuestion.Size = new Size(243, 68);
            lblQuestion.TabIndex = 0;
            lblQuestion.Text = "lblQuestion";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.None;
            tableLayoutPanel1.BackColor = Color.Transparent;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(rbtnAns4, 1, 1);
            tableLayoutPanel1.Controls.Add(rbtnAns3, 0, 1);
            tableLayoutPanel1.Controls.Add(rbtnAns2, 1, 0);
            tableLayoutPanel1.Controls.Add(rbtnAns1, 0, 0);
            tableLayoutPanel1.Location = new Point(55, 122);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(662, 316);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // rbtnAns4
            // 
            rbtnAns4.Anchor = AnchorStyles.None;
            rbtnAns4.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns4.BorderColor = Color.Transparent;
            rbtnAns4.BorderSize = 0;
            rbtnAns4.FlatAppearance.BorderSize = 0;
            rbtnAns4.FlatStyle = FlatStyle.Flat;
            rbtnAns4.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns4.ForeColor = Color.White;
            rbtnAns4.Glass = false;
            rbtnAns4.Location = new Point(368, 164);
            rbtnAns4.Name = "rbtnAns4";
            rbtnAns4.PanelColor = Color.Empty;
            rbtnAns4.Radius = 10;
            rbtnAns4.Size = new Size(256, 145);
            rbtnAns4.TabIndex = 3;
            rbtnAns4.Text = "rbtnAns4";
            rbtnAns4.UseVisualStyleBackColor = false;
            rbtnAns4.Click += ButtonFourClick;
            // 
            // rbtnAns3
            // 
            rbtnAns3.Anchor = AnchorStyles.None;
            rbtnAns3.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns3.BorderColor = Color.Transparent;
            rbtnAns3.BorderSize = 0;
            rbtnAns3.FlatAppearance.BorderSize = 0;
            rbtnAns3.FlatStyle = FlatStyle.Flat;
            rbtnAns3.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns3.ForeColor = Color.White;
            rbtnAns3.Glass = false;
            rbtnAns3.Location = new Point(37, 164);
            rbtnAns3.Name = "rbtnAns3";
            rbtnAns3.PanelColor = Color.Empty;
            rbtnAns3.Radius = 10;
            rbtnAns3.Size = new Size(256, 145);
            rbtnAns3.TabIndex = 2;
            rbtnAns3.Text = "rbtnAns3";
            rbtnAns3.UseVisualStyleBackColor = false;
            rbtnAns3.Click += ButtonThreeClick;
            // 
            // rbtnAns2
            // 
            rbtnAns2.Anchor = AnchorStyles.None;
            rbtnAns2.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns2.BorderColor = Color.Transparent;
            rbtnAns2.BorderSize = 0;
            rbtnAns2.FlatAppearance.BorderSize = 0;
            rbtnAns2.FlatStyle = FlatStyle.Flat;
            rbtnAns2.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns2.ForeColor = Color.White;
            rbtnAns2.Glass = false;
            rbtnAns2.Location = new Point(368, 6);
            rbtnAns2.Name = "rbtnAns2";
            rbtnAns2.PanelColor = Color.Empty;
            rbtnAns2.Radius = 10;
            rbtnAns2.Size = new Size(256, 145);
            rbtnAns2.TabIndex = 1;
            rbtnAns2.Text = "rbtnAns2";
            rbtnAns2.UseVisualStyleBackColor = false;
            rbtnAns2.Click += ButtonTwoClick;
            // 
            // rbtnAns1
            // 
            rbtnAns1.Anchor = AnchorStyles.None;
            rbtnAns1.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns1.BorderColor = Color.Transparent;
            rbtnAns1.BorderSize = 0;
            rbtnAns1.FlatAppearance.BorderSize = 0;
            rbtnAns1.FlatStyle = FlatStyle.Flat;
            rbtnAns1.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns1.ForeColor = Color.White;
            rbtnAns1.Glass = false;
            rbtnAns1.Location = new Point(37, 6);
            rbtnAns1.Name = "rbtnAns1";
            rbtnAns1.PanelColor = Color.Empty;
            rbtnAns1.Radius = 10;
            rbtnAns1.Size = new Size(256, 145);
            rbtnAns1.TabIndex = 0;
            rbtnAns1.Text = "rbtnAns1";
            rbtnAns1.UseVisualStyleBackColor = false;
            rbtnAns1.Click += ButtonOneClick;
            // 
            // MultipleChoiceScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(53, 97, 68);
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(lblQuestion);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "MultipleChoiceScreen";
            Text = "BlankScreen1";
            WindowState = FormWindowState.Maximized;
            Click += MultipleChoiceScreen_Click;
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblQuestion;
        private TableLayoutPanel tableLayoutPanel1;
        private AdventForm.RoundedButton rbtnAns1;
        private AdventForm.RoundedButton rbtnAns4;
        private AdventForm.RoundedButton rbtnAns3;
        private AdventForm.RoundedButton rbtnAns2;
    }
}
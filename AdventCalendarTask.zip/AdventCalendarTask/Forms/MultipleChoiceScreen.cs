﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdventCalendarTask.Assets;

namespace AdventCalendarTask.Forms
{
    public partial class MultipleChoiceScreen : Form
    {
        public static Random rnd = new();
        int questionChoice;

        public MultipleChoiceScreen()
        {
            InitializeComponent();

            lblQuestion.Left = (this.ClientSize.Width - lblQuestion.Width) / 2;

            this.DoubleBuffered = true;

            questionChoice = rnd.Next(0, Question._questions.Count);
            lblQuestion.Text = Question._questions[questionChoice].QuestionText;
            rbtnAns1.Text = Question._questions[questionChoice].Answers[0];
            rbtnAns2.Text = Question._questions[questionChoice].Answers[1];
            rbtnAns3.Text = Question._questions[questionChoice].Answers[2];
            rbtnAns4.Text = Question._questions[questionChoice].Answers[3];
        }

        private void ButtonOneClick(object sender, EventArgs e)
        {
            CheckAnswer(0);
        }

        private void ButtonTwoClick(object sender, EventArgs e)
        {
            CheckAnswer(1);
        }

        private void ButtonThreeClick(object sender, EventArgs e)
        {
            CheckAnswer(2);
        }

        private void ButtonFourClick(object sender, EventArgs e)
        {
            CheckAnswer(3);
        }

        private void CheckAnswer(int answer)
        {
            if (answer == Question._questions[questionChoice].CorrectAnswerPosition)
            {
                new CorrectScreen().Show();
                Hide();
            }
            else
            {
                new IncorrectScreen().Show();
                Hide();
            }
        }

        private void MultipleChoiceScreen_Click(object sender, EventArgs e)
        {

        }
    }
}

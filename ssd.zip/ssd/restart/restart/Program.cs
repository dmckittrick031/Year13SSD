﻿namespace Method_Threading
{
    internal class Program
    {
        long listLength = 0;
        static void Main(string[] args)
        {
            List<long> userNumList = new();
            for (int i = 0; i < 5; i++)
            {
                long numInpt = Convert.ToInt64(Console.ReadLine());

                userNumList.Add(numInpt);
            }
            AddNums(userNumList);
            Console.ReadLine();
            
        }
        public static long AddNums(List<long> numList)
        {
            Console.WriteLine($"Your numbers, when added equal {numList.Sum()}");
            foreach (long number in numList)
            {
                if ((number % 2) > 0)
                {
                    Console.WriteLine($"{number} is even.");
                }
                else
                {
                    Console.WriteLine($"{number} is odd.");
                }
            }

            var listLength = numList.Count;
            return listLength;
        }
    }
}
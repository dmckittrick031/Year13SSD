namespace PolymorphismForm
{
    public partial class frmVoidMethods : Form
    {
        string?[,] CustomerDb = new string[6, 5]
             {
             {"000001","Allstate NI","100","20","120"},
             {"000002","May Jones","200","40","240"},
             {"000003","Alison Smyth","300","60","360"},
             {"000004","Albert Jones","400","80","480"},
             {"000005","Andrew White","500","100","600"},
             {"000006","Peter Brown","600","120","720"}
             };

        string? userOrderInput;

        public frmVoidMethods()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void GetOrderNumber()
        {
            userOrderInput = txtOrderInput.Text;
        }

        public int CountListItems()
        {
            txtTotalOrder.Text = CustomerDb.GetLength(0).ToString();
            MessageBox.Show($"The total number of orders is {CustomerDb.GetLength(0)}", "Total Orders");
            return CustomerDb.GetLength(0);
        }

        public void GetOrderDetail()
        {
            lstOrderDetails.Items.Clear();

            for (int row = 0; row < CustomerDb.GetLength(0); row++)
            {
                if (CustomerDb[row, 0] == userOrderInput || userOrderInput == "*")
                {
                    ListViewItem orderListView = new(CustomerDb[row, 0]);

                    for (int column = 1; column < CustomerDb.GetLength(1); column++)
                    {
                        if (column < 2)
                        {
                            orderListView.SubItems.Add(CustomerDb[row, column]);
                        }
                        else
                        {
                            orderListView.SubItems.Add($"�{CustomerDb[row, column]}");
                        }
                    }
                    lstOrderDetails.Items.Add(orderListView);
                }
                else
                {

                }
            }
        }

        public void TotalOrderCost(int thisOrderCost, out int thisOrderVat, out int totalNetValue)
        {
            thisOrderVat = thisOrderCost * 20 / 120;
            totalNetValue = thisOrderCost * 100 / 120;
        }

        public double CostOfOrders(params double[] orderValues)
        {
            double totalOrderValues = 0;

            foreach (double value in orderValues)
            {
                totalOrderValues += value;
            }

            return totalOrderValues;
        }

        private double AverageOrderCost(string title, params int[] orderVal)
        {
            double sum = 0;
            double avg = 0;

            for (int i = 0; i < orderVal.Length; i++)
            {
                sum += orderVal[i];
            }
            avg = sum / orderVal.Length;
            return avg;
        }

        private double TotalOrderAmount(int valOne, int valTwo)
        {
            double sum = 0;

            sum = valOne + valTwo;

            return sum;
        }

        private double TotalOrderAmount(int valOne, int valTwo, int valThree)
        {
            double sum = 0;

            sum = valOne + valTwo + valThree;

            return sum;
        }

        private double TotalOrderAmount(double valOne, double valTwo, double valThree)
        {
            double sum = 0;

            sum = valOne + valTwo + valThree;

            return sum;
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lstOrderDetails_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            GetOrderNumber();
            GetOrderDetail();
        }

        private void btnSearchAllRecords_Click(object sender, EventArgs e)
        {
            userOrderInput = "*";
            GetOrderDetail();
            CountListItems();
        }

        private void txtTotalOrder_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lstOrderDetails.Items.Clear();
            double totalOrderValue = 0;
            double avgOrderValue = 0;

            totalOrderValue = CostOfOrders(200, 300, 500);
            lstOrderDetails.Items.Add(totalOrderValue.ToString("C"));

            int[] arrOrders = new int[] { 200, 300, 500 };
            avgOrderValue = AverageOrderCost("Set of Values One", arrOrders);
            lstOrderDetails.Items.Add(avgOrderValue.ToString("C"));

            totalOrderValue = TotalOrderAmount(200, 300);
            lstOrderDetails.Items.Add(totalOrderValue.ToString("C"));

            totalOrderValue = TotalOrderAmount(200, 300, 500);
            lstOrderDetails.Items.Add(totalOrderValue.ToString("C"));

            totalOrderValue = TotalOrderAmount(200.5, 300.25, 499.25);
            lstOrderDetails.Items.Add(totalOrderValue.ToString("C"));
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
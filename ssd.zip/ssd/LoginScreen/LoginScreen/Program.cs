﻿namespace LoginScreen
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your username:");
            string userName = Console.ReadLine();
            Console.WriteLine("Please enter your password:");
            string userPass = Console.ReadLine();

            switch (userName)
            {
                case "admin":
                    switch (userPass)
                    {
                        case "1234":
                            Console.WriteLine("ACCESS GRANTED");
                            break;

                        default:
                            Console.WriteLine("PASSWORD INCORRECT");
                            break;
                    }
                    break;

                default:
                    Console.WriteLine("ACCESS DENIED");
                    break;
            }
            Console.ReadLine();

        }
    }
}
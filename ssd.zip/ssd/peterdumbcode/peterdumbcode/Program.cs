﻿namespace peterdumbcode
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string? userHexInput = Console.ReadLine();
            List<long> hexSum = new List<long>();
            int finalHex;

            foreach (char userDigit in userHexInput.ToUpper())
            {
                switch (userDigit)
                {
                    case '1':
                        hexSum.Add(1);
                        break;
                    case '2':
                        hexSum.Add(2);
                        break;
                    case '3':
                        hexSum.Add(3);
                        break;
                    case '4':
                        hexSum.Add(4);
                        break;
                    case '5':
                        hexSum.Add(5);
                        break;
                    case '6':
                        hexSum.Add(6);
                        break;
                    case '7':
                        hexSum.Add(7);
                        break;
                    case '8':
                        hexSum.Add(8);
                        break;
                    case '9':
                        hexSum.Add(9);
                        break;
                    case 'A':
                        hexSum.Add(10);
                        break;
                    case 'B':
                        hexSum.Add(11);
                        break;
                    case 'C':
                        hexSum.Add(12);
                        break;
                    case 'D':
                        hexSum.Add(13);
                        break;
                    case 'E':
                        hexSum.Add(14);
                        break;
                    case 'F':
                        hexSum.Add(15);
                        break;
                    default:
                        break;
                }
            }
            for (int i = 0; i < hexSum.Count; i++)
            {
                int mult = hexSum[i] *= hexSum[i+1];
                return mult;
            }
            Console.WriteLine($"Your hex number in denary is {mult}.");
            Console.ReadLine();
        }
    }
}                                                                                                                                                                                                                                                                                                                                                                                                                                     
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventCalendarTask.Controls
{
    public class ColorProgressBar : ProgressBar
    {
        [Description("Changes the color that fills the bar."), Category("Appearance")]
        public Color ProgressColor { get; set; } = Color.Blue;
        
        public ColorProgressBar()
        {
            this.SetStyle(ControlStyles.UserPaint, true);

        }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            using (Graphics g = e.Graphics)
            {
                g.Clear(BackColor);
                using (Brush brush = new SolidBrush(ProgressColor))
                {
                    int width = (int)(Width * ((double)Value / Maximum));
                    g.FillRectangle(brush, 0, 0, width, Height);
                }
                using (Pen pen = new Pen(ForeColor))
                {
                    g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
                }
            }
        }
    }
}

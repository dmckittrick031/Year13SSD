﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdventCalendarTask.Assets;

namespace AdventCalendarTask.Forms
{
    public partial class CalendarScreen : Form
    {
        public CalendarScreen()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
        }

        private void ButtonClick(object sender, EventArgs e)
        {
            Random rnd = new();

            Button button = (Button)sender;
           
            int questionType = rnd.Next(0, 3);

            button.Visible = false;

            switch (questionType)
            {
                case 0:
                    new DragDropScreen().Show();
                    Hide();
                    break;
                case 1:
                    new MultipleChoiceScreen().Show();
                    Hide();
                    break;
                case 2:
                    new TrueFalseScreen().Show();
                    Hide();
                    break;
                default:
                    throw new Exception();
            }
        }
    }
}

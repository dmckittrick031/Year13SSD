﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] arrBook = new string[50];
        }
    }
}
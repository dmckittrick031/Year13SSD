﻿namespace ArraysLists
{
    internal class Program
    {
        static void Main(string[] args)
        {
            long rows;
            long columns;

            Console.WriteLine("How many rows would you like?");
            Console.Write("> ");
            long matrixRows = long.TryParse(Console.ReadLine(), out rows) ? rows : 0;
            Console.Clear();


            Console.WriteLine("How many rows would you like?");
            Console.Write("> ");
            long matrixColumns = long.TryParse(Console.ReadLine(), out columns) ? columns : 0;
            Console.Clear();

            long[,] timesTable = new long[rows, columns];

            for (int p = 0; p < timesTable.GetLength(0); p++)
            {
                for (int k = 0; k < timesTable.GetLength(1); k++)
                {
                    timesTable[p, k] = (p + 1) * (k + 1);
                }
                Console.WriteLine();
            }


            for (int i = 0; i < timesTable.GetLength(0); i++)
            {
                for (int k = 0; k < timesTable.GetLength(1); k++)
                {
                    Console.Write(timesTable[i, k]+"    ");
                }
                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}

﻿namespace multiArray
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tbColumns_Scroll(object sender, EventArgs e)
        {
            textColumns.Text = tbColumns.Value.ToString();
        }

        private void tbRows_Scroll(object sender, EventArgs e)
        {
            textRows.Text = tbRows.Value.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void arrDisplay_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textColumns_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEXE_Click(object sender, EventArgs e)
        {
            arrDisplay.Items.Clear();
            if (tbColumns.Value == 0 && tbRows.Value == 0)
            {
                MessageBox.Show("Please input a value");
            }
            else if (tbColumns.Value == 0)
            {
                MessageBox.Show("Please input a valid amount of columns");
            }
            else if (tbRows.Value == 0)
            {
                MessageBox.Show("Please input a valid number of rows");
            }
            else
            {
                long[,] timesTable = new long[tbRows.Value, tbColumns.Value];

                for (int p = 0; p < timesTable.GetLength(0); p++)
                {
                    for (int k = 0; k < timesTable.GetLength(1); k++)
                    {
                        timesTable[p, k] = (p + 1) * (k + 1);
                    }
                }


                for (int i = 0; i < timesTable.GetLength(0); i++)
                {
                    arrDisplay.Items.Add($"{i + 1} TIMES TABLE \n\n");
                    arrDisplay.Items.Add("");
                    for (int k = 0; k < timesTable.GetLength(1); k++)
                    {
                        arrDisplay.Items.Add($"{i+1} x {k+1} = {timesTable[i, k]}");
                    }
                    arrDisplay.Items.Add("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            arrDisplay.Items.Clear();
            tbRows.Value = 0;
            tbColumns.Value = 0;
            textRows.Text = "0";
            textColumns.Text = "0";
        }
    }
}
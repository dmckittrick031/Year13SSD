﻿namespace AdventCalendarTask.Forms
{
    partial class CalendarScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tblCalendar = new TableLayoutPanel();
            btn24 = new Button();
            btn23 = new Button();
            btn22 = new Button();
            btn21 = new Button();
            btn20 = new Button();
            btn19 = new Button();
            btn18 = new Button();
            btn17 = new Button();
            btn16 = new Button();
            btn15 = new Button();
            btn14 = new Button();
            btn13 = new Button();
            btn12 = new Button();
            btn11 = new Button();
            btn10 = new Button();
            btn9 = new Button();
            btn8 = new Button();
            btn7 = new Button();
            btn6 = new Button();
            btn5 = new Button();
            btn4 = new Button();
            btn3 = new Button();
            btn2 = new Button();
            btn1 = new Button();
            tblCalendar.SuspendLayout();
            SuspendLayout();
            // 
            // tblCalendar
            // 
            tblCalendar.BackColor = Color.Transparent;
            tblCalendar.ColumnCount = 6;
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666718F));
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666679F));
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666679F));
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666679F));
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666679F));
            tblCalendar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.6666679F));
            tblCalendar.Controls.Add(btn24, 5, 3);
            tblCalendar.Controls.Add(btn23, 4, 3);
            tblCalendar.Controls.Add(btn22, 3, 3);
            tblCalendar.Controls.Add(btn21, 2, 3);
            tblCalendar.Controls.Add(btn20, 1, 3);
            tblCalendar.Controls.Add(btn19, 0, 3);
            tblCalendar.Controls.Add(btn18, 5, 2);
            tblCalendar.Controls.Add(btn17, 4, 2);
            tblCalendar.Controls.Add(btn16, 3, 2);
            tblCalendar.Controls.Add(btn15, 2, 2);
            tblCalendar.Controls.Add(btn14, 1, 2);
            tblCalendar.Controls.Add(btn13, 0, 2);
            tblCalendar.Controls.Add(btn12, 5, 1);
            tblCalendar.Controls.Add(btn11, 4, 1);
            tblCalendar.Controls.Add(btn10, 3, 1);
            tblCalendar.Controls.Add(btn9, 2, 1);
            tblCalendar.Controls.Add(btn8, 1, 1);
            tblCalendar.Controls.Add(btn7, 0, 1);
            tblCalendar.Controls.Add(btn6, 5, 0);
            tblCalendar.Controls.Add(btn5, 4, 0);
            tblCalendar.Controls.Add(btn4, 3, 0);
            tblCalendar.Controls.Add(btn3, 2, 0);
            tblCalendar.Controls.Add(btn2, 1, 0);
            tblCalendar.Controls.Add(btn1, 0, 0);
            tblCalendar.Dock = DockStyle.Fill;
            tblCalendar.Location = new Point(0, 0);
            tblCalendar.Margin = new Padding(10);
            tblCalendar.Name = "tblCalendar";
            tblCalendar.RowCount = 4;
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Percent, 25.0000038F));
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Absolute, 69F));
            tblCalendar.RowStyles.Add(new RowStyle(SizeType.Absolute, 69F));
            tblCalendar.Size = new Size(1600, 900);
            tblCalendar.TabIndex = 0;
            // 
            // btn24
            // 
            btn24.Anchor = AnchorStyles.None;
            btn24.BackgroundImage = Properties.Resources.presentbutton;
            btn24.BackgroundImageLayout = ImageLayout.Stretch;
            btn24.FlatAppearance.BorderSize = 0;
            btn24.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn24.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn24.FlatStyle = FlatStyle.Flat;
            btn24.Location = new Point(1393, 716);
            btn24.Margin = new Padding(10);
            btn24.Name = "btn24";
            btn24.Size = new Size(143, 143);
            btn24.TabIndex = 23;
            btn24.Text = "24";
            btn24.UseVisualStyleBackColor = true;
            btn24.Click += ButtonClick;
            // 
            // btn23
            // 
            btn23.Anchor = AnchorStyles.None;
            btn23.BackgroundImage = Properties.Resources.presentbutton;
            btn23.BackgroundImageLayout = ImageLayout.Stretch;
            btn23.FlatAppearance.BorderSize = 0;
            btn23.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn23.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn23.FlatStyle = FlatStyle.Flat;
            btn23.Location = new Point(1125, 716);
            btn23.Margin = new Padding(10);
            btn23.Name = "btn23";
            btn23.Size = new Size(143, 143);
            btn23.TabIndex = 22;
            btn23.Text = "23";
            btn23.UseVisualStyleBackColor = true;
            btn23.Click += ButtonClick;
            // 
            // btn22
            // 
            btn22.Anchor = AnchorStyles.None;
            btn22.BackgroundImage = Properties.Resources.presentbutton;
            btn22.BackgroundImageLayout = ImageLayout.Stretch;
            btn22.FlatAppearance.BorderSize = 0;
            btn22.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn22.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn22.FlatStyle = FlatStyle.Flat;
            btn22.Location = new Point(859, 716);
            btn22.Margin = new Padding(10);
            btn22.Name = "btn22";
            btn22.Size = new Size(143, 143);
            btn22.TabIndex = 21;
            btn22.Text = "22";
            btn22.UseVisualStyleBackColor = true;
            btn22.Click += ButtonClick;
            // 
            // btn21
            // 
            btn21.Anchor = AnchorStyles.None;
            btn21.BackgroundImage = Properties.Resources.presentbutton;
            btn21.BackgroundImageLayout = ImageLayout.Stretch;
            btn21.FlatAppearance.BorderSize = 0;
            btn21.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn21.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn21.FlatStyle = FlatStyle.Flat;
            btn21.Location = new Point(593, 716);
            btn21.Margin = new Padding(10);
            btn21.Name = "btn21";
            btn21.Size = new Size(143, 143);
            btn21.TabIndex = 20;
            btn21.Text = "21";
            btn21.UseVisualStyleBackColor = true;
            btn21.Click += ButtonClick;
            // 
            // btn20
            // 
            btn20.Anchor = AnchorStyles.None;
            btn20.BackgroundImage = Properties.Resources.presentbutton;
            btn20.BackgroundImageLayout = ImageLayout.Stretch;
            btn20.FlatAppearance.BorderSize = 0;
            btn20.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn20.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn20.FlatStyle = FlatStyle.Flat;
            btn20.Location = new Point(327, 716);
            btn20.Margin = new Padding(10);
            btn20.Name = "btn20";
            btn20.Size = new Size(143, 143);
            btn20.TabIndex = 19;
            btn20.Text = "20";
            btn20.UseVisualStyleBackColor = true;
            btn20.Click += ButtonClick;
            // 
            // btn19
            // 
            btn19.Anchor = AnchorStyles.None;
            btn19.BackgroundImage = Properties.Resources.presentbutton;
            btn19.BackgroundImageLayout = ImageLayout.Stretch;
            btn19.FlatAppearance.BorderSize = 0;
            btn19.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn19.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn19.FlatStyle = FlatStyle.Flat;
            btn19.Location = new Point(61, 716);
            btn19.Margin = new Padding(10);
            btn19.Name = "btn19";
            btn19.Size = new Size(143, 143);
            btn19.TabIndex = 18;
            btn19.Text = "19";
            btn19.UseVisualStyleBackColor = true;
            btn19.Click += ButtonClick;
            // 
            // btn18
            // 
            btn18.Anchor = AnchorStyles.None;
            btn18.BackgroundImage = Properties.Resources.presentbutton;
            btn18.BackgroundImageLayout = ImageLayout.Stretch;
            btn18.FlatAppearance.BorderSize = 0;
            btn18.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn18.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn18.FlatStyle = FlatStyle.Flat;
            btn18.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn18.ForeColor = Color.White;
            btn18.Location = new Point(1393, 491);
            btn18.Margin = new Padding(10);
            btn18.Name = "btn18";
            btn18.Size = new Size(143, 143);
            btn18.TabIndex = 17;
            btn18.Text = "18";
            btn18.UseVisualStyleBackColor = true;
            btn18.Click += ButtonClick;
            // 
            // btn17
            // 
            btn17.Anchor = AnchorStyles.None;
            btn17.BackgroundImage = Properties.Resources.presentbutton;
            btn17.BackgroundImageLayout = ImageLayout.Stretch;
            btn17.FlatAppearance.BorderSize = 0;
            btn17.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn17.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn17.FlatStyle = FlatStyle.Flat;
            btn17.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn17.ForeColor = Color.White;
            btn17.Location = new Point(1125, 491);
            btn17.Margin = new Padding(10);
            btn17.Name = "btn17";
            btn17.Size = new Size(143, 143);
            btn17.TabIndex = 16;
            btn17.Text = "17";
            btn17.UseVisualStyleBackColor = true;
            btn17.Click += ButtonClick;
            // 
            // btn16
            // 
            btn16.Anchor = AnchorStyles.None;
            btn16.BackgroundImage = Properties.Resources.presentbutton;
            btn16.BackgroundImageLayout = ImageLayout.Stretch;
            btn16.FlatAppearance.BorderSize = 0;
            btn16.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn16.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn16.FlatStyle = FlatStyle.Flat;
            btn16.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn16.ForeColor = Color.White;
            btn16.Location = new Point(859, 491);
            btn16.Margin = new Padding(10);
            btn16.Name = "btn16";
            btn16.Size = new Size(143, 143);
            btn16.TabIndex = 15;
            btn16.Text = "16";
            btn16.UseVisualStyleBackColor = true;
            btn16.Click += ButtonClick;
            // 
            // btn15
            // 
            btn15.Anchor = AnchorStyles.None;
            btn15.BackgroundImage = Properties.Resources.presentbutton;
            btn15.BackgroundImageLayout = ImageLayout.Stretch;
            btn15.FlatAppearance.BorderSize = 0;
            btn15.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn15.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn15.FlatStyle = FlatStyle.Flat;
            btn15.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn15.ForeColor = Color.White;
            btn15.Location = new Point(593, 491);
            btn15.Margin = new Padding(10);
            btn15.Name = "btn15";
            btn15.Size = new Size(143, 143);
            btn15.TabIndex = 14;
            btn15.Text = "15";
            btn15.UseVisualStyleBackColor = true;
            btn15.Click += ButtonClick;
            // 
            // btn14
            // 
            btn14.Anchor = AnchorStyles.None;
            btn14.BackgroundImage = Properties.Resources.presentbutton;
            btn14.BackgroundImageLayout = ImageLayout.Stretch;
            btn14.FlatAppearance.BorderSize = 0;
            btn14.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn14.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn14.FlatStyle = FlatStyle.Flat;
            btn14.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn14.ForeColor = Color.White;
            btn14.Location = new Point(327, 491);
            btn14.Margin = new Padding(10);
            btn14.Name = "btn14";
            btn14.Size = new Size(143, 143);
            btn14.TabIndex = 13;
            btn14.Text = "14";
            btn14.UseVisualStyleBackColor = true;
            btn14.Click += ButtonClick;
            // 
            // btn13
            // 
            btn13.Anchor = AnchorStyles.None;
            btn13.BackgroundImage = Properties.Resources.presentbutton;
            btn13.BackgroundImageLayout = ImageLayout.Stretch;
            btn13.FlatAppearance.BorderSize = 0;
            btn13.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn13.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn13.FlatStyle = FlatStyle.Flat;
            btn13.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn13.ForeColor = Color.White;
            btn13.Location = new Point(61, 491);
            btn13.Margin = new Padding(10);
            btn13.Name = "btn13";
            btn13.Size = new Size(143, 143);
            btn13.TabIndex = 12;
            btn13.Text = "13";
            btn13.UseVisualStyleBackColor = true;
            btn13.Click += ButtonClick;
            // 
            // btn12
            // 
            btn12.Anchor = AnchorStyles.None;
            btn12.BackgroundImage = Properties.Resources.presentbutton;
            btn12.BackgroundImageLayout = ImageLayout.Stretch;
            btn12.FlatAppearance.BorderSize = 0;
            btn12.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn12.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn12.FlatStyle = FlatStyle.Flat;
            btn12.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn12.ForeColor = Color.White;
            btn12.Location = new Point(1393, 266);
            btn12.Margin = new Padding(10);
            btn12.Name = "btn12";
            btn12.Size = new Size(143, 143);
            btn12.TabIndex = 11;
            btn12.Text = "12";
            btn12.UseVisualStyleBackColor = true;
            btn12.Click += ButtonClick;
            // 
            // btn11
            // 
            btn11.Anchor = AnchorStyles.None;
            btn11.BackgroundImage = Properties.Resources.presentbutton;
            btn11.BackgroundImageLayout = ImageLayout.Stretch;
            btn11.FlatAppearance.BorderSize = 0;
            btn11.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn11.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn11.FlatStyle = FlatStyle.Flat;
            btn11.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn11.ForeColor = Color.White;
            btn11.Location = new Point(1125, 266);
            btn11.Margin = new Padding(10);
            btn11.Name = "btn11";
            btn11.Size = new Size(143, 143);
            btn11.TabIndex = 10;
            btn11.Text = "11";
            btn11.UseVisualStyleBackColor = true;
            btn11.Click += ButtonClick;
            // 
            // btn10
            // 
            btn10.Anchor = AnchorStyles.None;
            btn10.BackgroundImage = Properties.Resources.presentbutton;
            btn10.BackgroundImageLayout = ImageLayout.Stretch;
            btn10.FlatAppearance.BorderSize = 0;
            btn10.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn10.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn10.FlatStyle = FlatStyle.Flat;
            btn10.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn10.ForeColor = Color.White;
            btn10.Location = new Point(859, 266);
            btn10.Margin = new Padding(10);
            btn10.Name = "btn10";
            btn10.Size = new Size(143, 143);
            btn10.TabIndex = 9;
            btn10.Text = "10";
            btn10.UseVisualStyleBackColor = true;
            btn10.Click += ButtonClick;
            // 
            // btn9
            // 
            btn9.Anchor = AnchorStyles.None;
            btn9.BackgroundImage = Properties.Resources.presentbutton;
            btn9.BackgroundImageLayout = ImageLayout.Stretch;
            btn9.FlatAppearance.BorderSize = 0;
            btn9.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn9.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn9.FlatStyle = FlatStyle.Flat;
            btn9.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn9.ForeColor = Color.White;
            btn9.Location = new Point(593, 266);
            btn9.Margin = new Padding(10);
            btn9.Name = "btn9";
            btn9.Size = new Size(143, 143);
            btn9.TabIndex = 8;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += ButtonClick;
            // 
            // btn8
            // 
            btn8.Anchor = AnchorStyles.None;
            btn8.BackgroundImage = Properties.Resources.presentbutton;
            btn8.BackgroundImageLayout = ImageLayout.Stretch;
            btn8.FlatAppearance.BorderSize = 0;
            btn8.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn8.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn8.FlatStyle = FlatStyle.Flat;
            btn8.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn8.ForeColor = Color.White;
            btn8.Location = new Point(327, 266);
            btn8.Margin = new Padding(10);
            btn8.Name = "btn8";
            btn8.Size = new Size(143, 143);
            btn8.TabIndex = 7;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += ButtonClick;
            // 
            // btn7
            // 
            btn7.Anchor = AnchorStyles.None;
            btn7.BackgroundImage = Properties.Resources.presentbutton;
            btn7.BackgroundImageLayout = ImageLayout.Stretch;
            btn7.FlatAppearance.BorderSize = 0;
            btn7.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn7.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn7.FlatStyle = FlatStyle.Flat;
            btn7.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn7.ForeColor = Color.White;
            btn7.Location = new Point(61, 266);
            btn7.Margin = new Padding(10);
            btn7.Name = "btn7";
            btn7.Size = new Size(143, 143);
            btn7.TabIndex = 6;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += ButtonClick;
            // 
            // btn6
            // 
            btn6.Anchor = AnchorStyles.None;
            btn6.BackgroundImage = Properties.Resources.presentbutton;
            btn6.BackgroundImageLayout = ImageLayout.Stretch;
            btn6.FlatAppearance.BorderSize = 0;
            btn6.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn6.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn6.FlatStyle = FlatStyle.Flat;
            btn6.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn6.ForeColor = Color.White;
            btn6.Location = new Point(1393, 41);
            btn6.Margin = new Padding(10);
            btn6.Name = "btn6";
            btn6.Size = new Size(143, 143);
            btn6.TabIndex = 5;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += ButtonClick;
            // 
            // btn5
            // 
            btn5.Anchor = AnchorStyles.None;
            btn5.BackgroundImage = Properties.Resources.presentbutton;
            btn5.BackgroundImageLayout = ImageLayout.Stretch;
            btn5.FlatAppearance.BorderSize = 0;
            btn5.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn5.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn5.FlatStyle = FlatStyle.Flat;
            btn5.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn5.ForeColor = Color.White;
            btn5.Location = new Point(1125, 41);
            btn5.Margin = new Padding(10);
            btn5.Name = "btn5";
            btn5.Size = new Size(143, 143);
            btn5.TabIndex = 4;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += ButtonClick;
            // 
            // btn4
            // 
            btn4.Anchor = AnchorStyles.None;
            btn4.BackgroundImage = Properties.Resources.presentbutton;
            btn4.BackgroundImageLayout = ImageLayout.Stretch;
            btn4.FlatAppearance.BorderSize = 0;
            btn4.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn4.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn4.FlatStyle = FlatStyle.Flat;
            btn4.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn4.ForeColor = Color.White;
            btn4.Location = new Point(859, 41);
            btn4.Margin = new Padding(10);
            btn4.Name = "btn4";
            btn4.Size = new Size(143, 143);
            btn4.TabIndex = 3;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += ButtonClick;
            // 
            // btn3
            // 
            btn3.Anchor = AnchorStyles.None;
            btn3.BackgroundImage = Properties.Resources.presentbutton;
            btn3.BackgroundImageLayout = ImageLayout.Stretch;
            btn3.FlatAppearance.BorderSize = 0;
            btn3.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn3.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn3.FlatStyle = FlatStyle.Flat;
            btn3.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn3.ForeColor = Color.White;
            btn3.Location = new Point(593, 41);
            btn3.Margin = new Padding(10);
            btn3.Name = "btn3";
            btn3.Size = new Size(143, 143);
            btn3.TabIndex = 2;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += ButtonClick;
            // 
            // btn2
            // 
            btn2.Anchor = AnchorStyles.None;
            btn2.BackgroundImage = Properties.Resources.presentbutton;
            btn2.BackgroundImageLayout = ImageLayout.Stretch;
            btn2.FlatAppearance.BorderSize = 0;
            btn2.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn2.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn2.FlatStyle = FlatStyle.Flat;
            btn2.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn2.ForeColor = Color.White;
            btn2.Location = new Point(327, 41);
            btn2.Margin = new Padding(10);
            btn2.Name = "btn2";
            btn2.Size = new Size(143, 143);
            btn2.TabIndex = 1;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += ButtonClick;
            // 
            // btn1
            // 
            btn1.Anchor = AnchorStyles.None;
            btn1.BackgroundImage = Properties.Resources.presentbutton;
            btn1.BackgroundImageLayout = ImageLayout.Stretch;
            btn1.FlatAppearance.BorderSize = 0;
            btn1.FlatAppearance.MouseDownBackColor = Color.FromArgb(13, 57, 28);
            btn1.FlatAppearance.MouseOverBackColor = Color.FromArgb(33, 77, 48);
            btn1.FlatStyle = FlatStyle.Flat;
            btn1.Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            btn1.ForeColor = Color.White;
            btn1.Location = new Point(61, 41);
            btn1.Margin = new Padding(10);
            btn1.Name = "btn1";
            btn1.Size = new Size(143, 143);
            btn1.TabIndex = 0;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += ButtonClick;
            // 
            // CalendarScreen
            // 
            AutoScaleDimensions = new SizeF(24F, 52F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1600, 900);
            Controls.Add(tblCalendar);
            DoubleBuffered = true;
            Font = new Font("Bahnschrift", 32F, FontStyle.Regular, GraphicsUnit.Point);
            ForeColor = Color.White;
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(10);
            Name = "CalendarScreen";
            Text = "BlankScreen1";
            WindowState = FormWindowState.Maximized;
            tblCalendar.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tblCalendar;
        private Button btn1;
        private Button btn4;
        private Button btn3;
        private Button btn2;
        private Button btn24;
        private Button btn23;
        private Button btn22;
        private Button btn21;
        private Button btn20;
        private Button btn19;
        private Button btn18;
        private Button btn17;
        private Button btn16;
        private Button btn15;
        private Button btn14;
        private Button btn13;
        private Button btn12;
        private Button btn11;
        private Button btn10;
        private Button btn9;
        private Button btn8;
        private Button btn7;
        private Button btn6;
        private Button btn5;
    }
}
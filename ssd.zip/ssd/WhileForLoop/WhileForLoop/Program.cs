﻿namespace WhileForLoop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> numList = new List<int>();
            int nthTerm = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < nthTerm; i++)
            {
                numList.Add(i+1);
            }
            Console.WriteLine(numList.Sum());
            Console.ReadLine();
        }
    }
}                                                                                                                                                                                                                                                                                                                                           
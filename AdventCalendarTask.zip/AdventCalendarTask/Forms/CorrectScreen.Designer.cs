﻿namespace AdventCalendarTask.Forms
{
    partial class CorrectScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCorrect = new Label();
            SuspendLayout();
            // 
            // lblCorrect
            // 
            lblCorrect.Anchor = AnchorStyles.None;
            lblCorrect.AutoSize = true;
            lblCorrect.BackColor = Color.Transparent;
            lblCorrect.Font = new Font("Bahnschrift", 200F, FontStyle.Regular, GraphicsUnit.Point);
            lblCorrect.ForeColor = Color.White;
            lblCorrect.Location = new Point(0, 0);
            lblCorrect.Name = "lblCorrect";
            lblCorrect.Size = new Size(1104, 320);
            lblCorrect.TabIndex = 0;
            lblCorrect.Text = "Correct!";
            lblCorrect.Click += lblCorrect_Click;
            // 
            // CorrectScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(lblCorrect);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "CorrectScreen";
            Text = "CorrectScreen";
            WindowState = FormWindowState.Maximized;
            Load += CorrectScreen_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCorrect;
    }
}
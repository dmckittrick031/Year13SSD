﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdventCalendarTask.Forms
{
    public partial class SplashScreen : Form
    {
        public SoundPlayer player = new(@"tf_music_upgrade_machine.wav");
        public SplashScreen()
        {
            InitializeComponent();
            tmrLoading.Start();
            this.DoubleBuffered = true;
        }

        private void tmrLoading_Tick(object sender, EventArgs e)
        {
            progLoading.Increment(5);

            if (progLoading.Value >= progLoading.Maximum)
            {
                tmrLoading.Stop();
                Hide();
                FormCache._loginScreen.Show();
            }
        }

        private void SplashScreen_Load(object sender, EventArgs e)
        {
            player.PlayLooping();
        }
    }
}

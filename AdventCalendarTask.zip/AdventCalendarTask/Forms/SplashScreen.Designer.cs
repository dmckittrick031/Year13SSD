﻿namespace AdventCalendarTask.Forms
{
    partial class SplashScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tmrLoading = new System.Windows.Forms.Timer(components);
            lblLoading = new Label();
            progLoading = new Controls.ColorProgressBar();
            SuspendLayout();
            // 
            // tmrLoading
            // 
            tmrLoading.Tick += tmrLoading_Tick;
            // 
            // lblLoading
            // 
            lblLoading.AutoSize = true;
            lblLoading.BackColor = Color.Transparent;
            lblLoading.Dock = DockStyle.Bottom;
            lblLoading.Font = new Font("Bahnschrift", 40F, FontStyle.Regular, GraphicsUnit.Point);
            lblLoading.ForeColor = Color.White;
            lblLoading.Location = new Point(0, 362);
            lblLoading.Name = "lblLoading";
            lblLoading.Size = new Size(255, 65);
            lblLoading.TabIndex = 7;
            lblLoading.Text = "Loading...";
            // 
            // progLoading
            // 
            progLoading.BackColor = Color.FromArgb(53, 97, 68);
            progLoading.Dock = DockStyle.Bottom;
            progLoading.ForeColor = Color.FromArgb(33, 77, 48);
            progLoading.Location = new Point(0, 427);
            progLoading.Name = "progLoading";
            progLoading.ProgressColor = Color.FromArgb(33, 77, 48);
            progLoading.Size = new Size(800, 23);
            progLoading.Step = 1;
            progLoading.Style = ProgressBarStyle.Continuous;
            progLoading.TabIndex = 6;
            // 
            // SplashScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(lblLoading);
            Controls.Add(progLoading);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "SplashScreen";
            Text = "SplashScreen1";
            WindowState = FormWindowState.Maximized;
            Load += SplashScreen_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Timer tmrLoading;
        private Label lblLoading;
        private Controls.ColorProgressBar progLoading;
    }
}
﻿namespace _100924
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            long ranNum = rnd.Next(0, 100);
            Console.WriteLine(ranNum);

            while (ranNum > 50)
            {
                Console.WriteLine($"Your number was {ranNum}");
                Console.ReadLine();
            }
            Console.ReadLine();
        }
    }
}
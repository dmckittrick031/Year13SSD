﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdventCalendarTask.Assets;

namespace AdventCalendarTask.Forms
{
    public partial class DragDropScreen : Form
    {
        public static Random rnd = new();
        int questionChoice = rnd.Next(0, Question._questions.Count);
        public DragDropScreen()
        {
            InitializeComponent();

            lblQuestion.Left = (this.ClientSize.Width - lblQuestion.Width) / 2;

            this.DoubleBuffered = true;

            lblQuestion.Text = Question._questions[questionChoice].QuestionText;
            lblAns1.Text = Question._questions[questionChoice].Answers[0];
            lblAns2.Text = Question._questions[questionChoice].Answers[1];
            lblAns3.Text = Question._questions[questionChoice].Answers[2];
            lblAns4.Text = Question._questions[questionChoice].Answers[3];

            lblQuestion.AllowDrop = true;
        }
        private void LabelGrabbed(object sender, MouseEventArgs e)
        {
            Label selected = (Label)sender;
            selected.DoDragDrop(selected.Text, DragDropEffects.Copy);
        }

        private void AllowDragDropCopy(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void WindowsDragDrop(object sender, DragEventArgs e)
        {
            string result = (string)e.Data.GetData(DataFormats.Text);

            if (result == Question._questions[questionChoice].Answers[Question._questions[questionChoice].CorrectAnswerPosition])
            {
                new CorrectScreen().Show();
                Hide();
            }
            else
            {
                new IncorrectScreen().Show();
                Hide();
            }
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void DragDropScreen_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<MobileAccount> accList = new()
            {
                new(0, "Galaxy A51", 0001),
                new(1, "iPhone 16", 0002),
                new(2, "Google Pixel 6", 0003)
            };

            Employee testEmployee = new("Peter", 24500);

            Console.WriteLine(testEmployee.GetEmployeeName());
            testEmployee.RaiseEmployeeSalary(94);
            Console.WriteLine(testEmployee.GetEmployeeSalary());

            accList[1].AddBalance(2.3652327237894234);
            accList[1].MakeCall(2);

            foreach (MobileAccount acc in accList)
            {
                Console.WriteLine($"Account Type - {acc.DisplayDetails(1)}\tDevice - {acc.DisplayDetails(2)}\tAccount ID - {acc.DisplayDetails(3)}\tAccount Balance - {Convert.ToDouble(acc.DisplayDetails(4)).ToString("C")}");
            }
            Console.ReadLine(); 
        }
    }
}
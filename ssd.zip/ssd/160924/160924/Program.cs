﻿namespace _160924
{
    internal class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("lin gan guliguliguli guachalin gan gu lin gan gu");
            }
        }
    }
}
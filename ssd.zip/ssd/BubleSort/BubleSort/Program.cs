﻿namespace BubleSort
{
    internal class Program
    {
        static void BubbleSort(long[] toSort)
        {
            for (int i = 0; i < toSort.Length; i++)
            {
                for (int k = 0; k < toSort.Length-1; k++)
                {
                    if (toSort[k] < toSort[k+1])
                    {
                        long[] temp = toSort[1];
                        toSort[k] = toSort[k+1];
                        toSort[k + 1] = temp;
                    }
                }
            }
            Console.WriteLine(string.Join(" ", toSort));
        }

        static void Main(string[] args)
        {
            long[] numbersToSort = {3, 4 , 7 , 2 , 9 , 1, 8};

            
        }
    }
}
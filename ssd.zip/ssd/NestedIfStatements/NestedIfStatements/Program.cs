﻿namespace NestedIfStatements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input a number:");
            int userNum = Convert.ToInt32(Console.ReadLine());
            int typeCheck = userNum % 2;

            switch (userNum) { 
                case (% 2 == 0):
                    Console.WriteLine($"{userNum} is even.");
                    break;
            }
        }
    }
}
﻿namespace binaryFiles
{
    internal class Program
    {
        static string? filePath = @"U:\Documents\saveTo\binaryFile.bin";
        static void Main(string[] args)
        {
            List<string?> lstNames = new() { "peter", "david", "lebron" };

            using (BinaryWriter bw = new(File.Open(filePath, FileMode.Append)))
            {
                foreach (string? score in lstNames)
                {
                    bw.Write(score);
                }
            }

            using (BinaryReader br = new(File.Open(filePath, FileMode.Open)))
            {
                long pos = 0;
                long length = (long) br.BaseStream.Length;

                while (pos < length)
                {
                    string i = br.ReadString();
                    Console.WriteLine(i.ToUpper());
                    pos += sizeof (long); 
                    
                }
            }
            Console.ReadLine();
        }
    }
}
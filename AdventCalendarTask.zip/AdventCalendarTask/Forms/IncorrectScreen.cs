﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdventCalendarTask.Assets;
using WMPLib;

namespace AdventCalendarTask.Forms
{
    public partial class IncorrectScreen : Form
    {
        public IncorrectScreen()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            WindowsMediaPlayer wplayer = new();
            lblCorrect.Left = (this.ClientSize.Width - lblCorrect.Width) / 2;
            lblCorrect.Top = (this.ClientSize.Height - lblCorrect.Height) / 2;

            Random rnd = new();
            int soundChoice = rnd.Next(0, 3);

            switch (soundChoice)
            {
                case 0:
                    wplayer.URL = "spy_no01.mp3";
                    wplayer.controls.play();
                    break;
                case 1:
                    wplayer.URL = "spy_no02.mp3";
                    wplayer.controls.play();
                    break;
                case 2:
                    wplayer.URL = "spy_no03.mp3";
                    wplayer.controls.play();
                    break;
                default:
                    break;
            }
        }

        private void lblCorrect_Click(object sender, EventArgs e)
        {
            FormCache._calendarScreen.Show();
            Hide();
        }

        private void IncorrectScreen_Load(object sender, EventArgs e)
        {

        }
    }
}

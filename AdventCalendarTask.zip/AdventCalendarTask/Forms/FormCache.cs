﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventCalendarTask.Forms
{
    static class FormCache
    {
        public static LoginScreen _loginScreen = new();
        public static RegisterScreen _registerScreen = new();
        public static SplashScreen _splashScreen = new();
        public static CalendarScreen _calendarScreen = new();
    }
}

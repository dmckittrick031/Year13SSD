﻿namespace AdventCalendarTask.Forms
{
    partial class DragDropScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblQuestion = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            lblAns4 = new Label();
            lblAns3 = new Label();
            lblAns2 = new Label();
            lblAns1 = new Label();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblQuestion
            // 
            lblQuestion.AutoSize = true;
            lblQuestion.BackColor = Color.Transparent;
            lblQuestion.Dock = DockStyle.Left;
            lblQuestion.Font = new Font("Bahnschrift", 30F, FontStyle.Regular, GraphicsUnit.Point);
            lblQuestion.ForeColor = Color.White;
            lblQuestion.Location = new Point(0, 0);
            lblQuestion.Name = "lblQuestion";
            lblQuestion.Padding = new Padding(10);
            lblQuestion.Size = new Size(243, 68);
            lblQuestion.TabIndex = 0;
            lblQuestion.Text = "lblQuestion";
            lblQuestion.TextAlign = ContentAlignment.MiddleCenter;
            lblQuestion.Click += lblQuestion_Click;
            lblQuestion.DragDrop += WindowsDragDrop;
            lblQuestion.DragEnter += AllowDragDropCopy;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.None;
            tableLayoutPanel1.BackColor = Color.Transparent;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(lblAns4, 1, 1);
            tableLayoutPanel1.Controls.Add(lblAns3, 0, 1);
            tableLayoutPanel1.Controls.Add(lblAns2, 1, 0);
            tableLayoutPanel1.Controls.Add(lblAns1, 0, 0);
            tableLayoutPanel1.Location = new Point(55, 122);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(662, 316);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // lblAns4
            // 
            lblAns4.Anchor = AnchorStyles.None;
            lblAns4.AutoSize = true;
            lblAns4.Font = new Font("Bahnschrift", 22F, FontStyle.Regular, GraphicsUnit.Point);
            lblAns4.ForeColor = Color.White;
            lblAns4.Location = new Point(437, 219);
            lblAns4.Name = "lblAns4";
            lblAns4.Size = new Size(118, 36);
            lblAns4.TabIndex = 3;
            lblAns4.Text = "lblAns4";
            lblAns4.MouseDown += LabelGrabbed;
            // 
            // lblAns3
            // 
            lblAns3.Anchor = AnchorStyles.None;
            lblAns3.AutoSize = true;
            lblAns3.Font = new Font("Bahnschrift", 22F, FontStyle.Regular, GraphicsUnit.Point);
            lblAns3.ForeColor = Color.White;
            lblAns3.Location = new Point(107, 219);
            lblAns3.Name = "lblAns3";
            lblAns3.Size = new Size(117, 36);
            lblAns3.TabIndex = 2;
            lblAns3.Text = "lblAns3";
            lblAns3.MouseDown += LabelGrabbed;
            // 
            // lblAns2
            // 
            lblAns2.Anchor = AnchorStyles.None;
            lblAns2.AutoSize = true;
            lblAns2.Font = new Font("Bahnschrift", 22F, FontStyle.Regular, GraphicsUnit.Point);
            lblAns2.ForeColor = Color.White;
            lblAns2.Location = new Point(438, 61);
            lblAns2.Name = "lblAns2";
            lblAns2.Size = new Size(116, 36);
            lblAns2.TabIndex = 1;
            lblAns2.Text = "lblAns2";
            lblAns2.MouseDown += LabelGrabbed;
            // 
            // lblAns1
            // 
            lblAns1.Anchor = AnchorStyles.None;
            lblAns1.AutoSize = true;
            lblAns1.Font = new Font("Bahnschrift", 22F, FontStyle.Regular, GraphicsUnit.Point);
            lblAns1.ForeColor = Color.White;
            lblAns1.Location = new Point(110, 61);
            lblAns1.Name = "lblAns1";
            lblAns1.Size = new Size(111, 36);
            lblAns1.TabIndex = 0;
            lblAns1.Text = "lblAns1";
            lblAns1.MouseDown += LabelGrabbed;
            // 
            // DragDropScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(53, 97, 68);
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(lblQuestion);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "DragDropScreen";
            Text = "BlankScreen1";
            WindowState = FormWindowState.Maximized;
            Load += DragDropScreen_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblQuestion;
        private TableLayoutPanel tableLayoutPanel1;
        private Label lblAns4;
        private Label lblAns3;
        private Label lblAns2;
        private Label lblAns1;
    }
}
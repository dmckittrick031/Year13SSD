﻿namespace AdventCalendarTask.Forms
{
    partial class TrueFalseScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblQuestion = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            rbtnAns2 = new AdventForm.RoundedButton();
            rbtnAns1 = new AdventForm.RoundedButton();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // lblQuestion
            // 
            lblQuestion.AutoSize = true;
            lblQuestion.BackColor = Color.Transparent;
            lblQuestion.Dock = DockStyle.Left;
            lblQuestion.Font = new Font("Bahnschrift", 30F, FontStyle.Regular, GraphicsUnit.Point);
            lblQuestion.ForeColor = Color.White;
            lblQuestion.Location = new Point(0, 0);
            lblQuestion.Name = "lblQuestion";
            lblQuestion.Padding = new Padding(10);
            lblQuestion.Size = new Size(243, 68);
            lblQuestion.TabIndex = 0;
            lblQuestion.Text = "lblQuestion";
            lblQuestion.TextAlign = ContentAlignment.MiddleCenter;
            lblQuestion.Click += lblQuestion_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.Anchor = AnchorStyles.None;
            tableLayoutPanel1.BackColor = Color.Transparent;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(rbtnAns2, 1, 0);
            tableLayoutPanel1.Controls.Add(rbtnAns1, 0, 0);
            tableLayoutPanel1.Location = new Point(55, 122);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(662, 316);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // rbtnAns2
            // 
            rbtnAns2.Anchor = AnchorStyles.None;
            rbtnAns2.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns2.BorderColor = Color.Transparent;
            rbtnAns2.BorderSize = 0;
            rbtnAns2.FlatAppearance.BorderSize = 0;
            rbtnAns2.FlatStyle = FlatStyle.Flat;
            rbtnAns2.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns2.ForeColor = Color.White;
            rbtnAns2.Glass = false;
            rbtnAns2.Location = new Point(368, 85);
            rbtnAns2.Name = "rbtnAns2";
            rbtnAns2.PanelColor = Color.Empty;
            rbtnAns2.Radius = 10;
            rbtnAns2.Size = new Size(256, 145);
            rbtnAns2.TabIndex = 1;
            rbtnAns2.Text = "rbtnAns2";
            rbtnAns2.UseVisualStyleBackColor = false;
            rbtnAns2.Click += ButtonTwoClick;
            // 
            // rbtnAns1
            // 
            rbtnAns1.Anchor = AnchorStyles.None;
            rbtnAns1.BackColor = Color.FromArgb(53, 97, 68);
            rbtnAns1.BorderColor = Color.Transparent;
            rbtnAns1.BorderSize = 0;
            rbtnAns1.FlatAppearance.BorderSize = 0;
            rbtnAns1.FlatStyle = FlatStyle.Flat;
            rbtnAns1.Font = new Font("Bahnschrift", 20F, FontStyle.Regular, GraphicsUnit.Point);
            rbtnAns1.ForeColor = Color.White;
            rbtnAns1.Glass = false;
            rbtnAns1.Location = new Point(37, 85);
            rbtnAns1.Name = "rbtnAns1";
            rbtnAns1.PanelColor = Color.Empty;
            rbtnAns1.Radius = 10;
            rbtnAns1.Size = new Size(256, 145);
            rbtnAns1.TabIndex = 0;
            rbtnAns1.Text = "rbtnAns1";
            rbtnAns1.UseVisualStyleBackColor = false;
            rbtnAns1.Click += ButtonOneClick;
            // 
            // TrueFalseScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(53, 97, 68);
            BackgroundImage = Properties.Resources.bgBlurred;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(lblQuestion);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "TrueFalseScreen";
            Text = "BlankScreen1";
            WindowState = FormWindowState.Maximized;
            Load += TrueFalseScreen_Load;
            tableLayoutPanel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblQuestion;
        private TableLayoutPanel tableLayoutPanel1;
        private AdventForm.RoundedButton rbtnAns1;
        private AdventForm.RoundedButton rbtnAns2;
    }
}
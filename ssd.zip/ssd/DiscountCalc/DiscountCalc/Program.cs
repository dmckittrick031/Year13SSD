﻿namespace DiscountCalc
{
    internal class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {
                Console.WriteLine("Please input the item's price:");
                Console.Write("> £");
                double itemPrice = Convert.ToDouble(Console.ReadLine());

                switch (itemPrice)
                {
                    case (>= 100):
                        switch (itemPrice)
                        {
                            case (< 200):
                                Console.WriteLine($"Your discounted price is £{itemPrice -= (itemPrice / 100) * 10}");
                                break;

                            case (>= 200):
                                Console.WriteLine($"Your discounted price is £{itemPrice -= (itemPrice / 100) * 20}");
                                break;
                        }
                        break;
                    default:
                        Console.WriteLine("You receive no discount as your price, {itemPrice}, is below £100.");
                        break;
                }
                Console.WriteLine("Press Enter to Continue");
                Console.ReadKey();
                Console.Clear();
            }
        }
    }
}
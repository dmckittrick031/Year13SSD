﻿using System.Text;

namespace FileStreamSSD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            FileStream wFile;
            string filePath = @"U:\Documents\saveTo\userFile.txt";
            byte[] byteData;

            Console.WriteLine("Please enter text to be saved: ");
            Console.Write("> ");
            string? userText = Console.ReadLine();

            using (var userFile = File.Create(filePath))
            {
                byteData = Encoding.Unicode.GetBytes(userText);
                userFile.Write(byteData, 0, byteData.Length);
            }
        }
    }
}
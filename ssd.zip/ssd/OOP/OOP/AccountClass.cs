﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    internal class MobileAccount
    {
        private string? accType, accDevice;
        private int? accID;
        private double? accBalance;
        private double? callCost = 0.245;
        private double? textCost = 0.078;

        public MobileAccount(int type, string device, int ID)
        {
            switch (type)
            {
                case (0):
                    accType = "Pay Monthly";
                    break;
                case (1):
                    accType = "Pay As Needed";
                    break;
                default:
                    accType = "UNKNOWN TYPE";
                    break;
            };

            accDevice = device;
            accID = ID;
            accBalance = 0;
        }

        public string? DisplayDetails(int? detailIndex)
        {
            switch (detailIndex)
            {
                case (1):
                    return accType;
                case (2):
                    return accDevice;
                case (3):
                    return Convert.ToString(accID);
                case (4):
                    return Convert.ToString(accBalance);
                default:
                    return "Error";
            }
        }

        public double? AddBalance(double? balAmount)
        {
            accBalance += balAmount;
            return accBalance;
        }

        public void MakeCall(int minutes)
        {
            accBalance -= minutes * callCost;
        }

        public void MakeText(int textCount)
        {
            accBalance -= textCount * textCost;
        }
        
    }
}

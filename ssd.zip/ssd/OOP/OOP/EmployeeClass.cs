﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    internal class Employee
    {
        private string? employeeName;
        private int? employeeSalary;

        public Employee(string? employeeName, int? employeeSalary)
        {
            this.employeeName = employeeName;
            this.employeeSalary = employeeSalary;
        }

        public string? GetEmployeeName()
        { 
            return this.employeeName;
        }

        public int? GetEmployeeSalary()
        {
            return this.employeeSalary;
        }

        public void RaiseEmployeeSalary(int raisePercent)
        {
            int? salaryIncrease = this.employeeSalary / 100 * raisePercent;
            this.employeeSalary += salaryIncrease;
        }
    }
}

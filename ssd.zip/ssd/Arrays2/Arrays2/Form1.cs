﻿namespace Arrays2
{
    public partial class Form1 : Form
    {
        private static List<string> strList = new();
        public Form1()
        {
            InitializeComponent();
        }

        private void lstArrays_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            lstArrays.Items.Clear();
            lstArrays.Items.Add("Array");
            lstArrays.Items.Add("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            for (int i = 0; i < strList.Count; i++)
            {
                lstArrays.Items.Add($"{i+1}: {strList[i]}");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lstArrays.Items.Clear();
            txtInptBox.Clear();
            strList.Clear();
            trackBar1.Maximum = strList.Count;
        }

        private void txtInptBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            trackBar1.Maximum = strList.Count;
            if (txtInptBox.Text == "")
            {
                MessageBox.Show("Please input a value.", "Input Empty Error");
            }
            else
            {
                strList.Add(txtInptBox.Text);
                txtInptBox.Clear();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textArrayDisp.Text = (trackBar1.Value+1).ToString();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (strList.Count == 0)
            {
                MessageBox.Show("The array has no values. Try entering a few.", "Array Empty Error");
            }
            else
            {
                strList.RemoveAt(trackBar1.Value);
                trackBar1.Maximum = strList.Count;
                lstArrays.Items.Clear();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            strList.Remove(txtInptBox.Text);
            lstArrays.Items.Clear();
            txtInptBox.Clear();
        }
    }
}
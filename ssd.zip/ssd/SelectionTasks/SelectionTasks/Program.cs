﻿namespace SelectionTasks
{
    internal class Program
    {
        static void Main(string[] args)
        
        {
            Console.WriteLine("Please enter your mark in the exam.");
            int userMark = Convert.ToInt32(Console.ReadLine());

            switch (userMark)
            {
                case >= 100:
                    Console.WriteLine("Please enter a valid mark.");
                    break;
                case >= 90:
                    Console.WriteLine("You received an A grade.");
                    break;
                case >= 80:
                    Console.WriteLine("You received a B grade");
                    break;
                case >= 70:
                    Console.WriteLine("You received a C grade");
                    break;
                case >= 65:
                    Console.WriteLine("You received a D grade");
                    break;
                case < 64:
                    Console.WriteLine("You have failed the exam.");
                    break;
                default:
                    while (userMark > 101)
                    {
                        Console.WriteLine("Please enter a valid number!");
                        userMark = Convert.ToInt32(Console.ReadLine());
                    }
                    return;
            }
            Console.ReadLine();
        }
    }
}
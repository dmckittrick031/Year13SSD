﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdventCalendarTask.Assets;

namespace AdventCalendarTask.Forms
{
    public partial class TrueFalseScreen : Form
    {
        public static Random rnd = new();
        int questionChoice;

        public TrueFalseScreen()
        {
            InitializeComponent();
            lblQuestion.Left = (this.ClientSize.Width - lblQuestion.Width) / 2;

            this.DoubleBuffered = true;
            questionChoice = rnd.Next(0, Question._questions.Count);
            lblQuestion.Text = Question._trueFalse[questionChoice].QuestionText;
            rbtnAns1.Text = Question._trueFalse[questionChoice].Answers[0];
            rbtnAns2.Text = Question._trueFalse[questionChoice].Answers[1];
        }

        private void ButtonOneClick(object sender, EventArgs e)
        {
            CheckAnswer(0);
        }

        private void ButtonTwoClick(object sender, EventArgs e)
        {
            CheckAnswer(1);
        }

        private void CheckAnswer(int answer)
        {
            if (answer == Question._trueFalse[questionChoice].CorrectAnswerPosition)
            {
                new CorrectScreen().Show();
                Hide();
            }
            else
            {
                new IncorrectScreen().Show();
                Hide();
            }
        }

        private void lblQuestion_Click(object sender, EventArgs e)
        {

        }

        private void TrueFalseScreen_Load(object sender, EventArgs e)
        {

        }
    }
}

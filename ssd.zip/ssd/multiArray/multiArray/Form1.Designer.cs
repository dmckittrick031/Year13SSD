﻿namespace multiArray
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbRows = new System.Windows.Forms.TrackBar();
            this.tbColumns = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.arrDisplay = new System.Windows.Forms.ListBox();
            this.textRows = new System.Windows.Forms.TextBox();
            this.textColumns = new System.Windows.Forms.TextBox();
            this.btnEXE = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tbRows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbColumns)).BeginInit();
            this.SuspendLayout();
            // 
            // tbRows
            // 
            this.tbRows.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbRows.Location = new System.Drawing.Point(66, 337);
            this.tbRows.Maximum = 25;
            this.tbRows.Name = "tbRows";
            this.tbRows.Size = new System.Drawing.Size(617, 45);
            this.tbRows.TabIndex = 0;
            this.tbRows.Scroll += new System.EventHandler(this.tbRows_Scroll);
            // 
            // tbColumns
            // 
            this.tbColumns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tbColumns.Location = new System.Drawing.Point(66, 388);
            this.tbColumns.Maximum = 25;
            this.tbColumns.Name = "tbColumns";
            this.tbColumns.Size = new System.Drawing.Size(617, 45);
            this.tbColumns.TabIndex = 1;
            this.tbColumns.Scroll += new System.EventHandler(this.tbColumns_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(66, 367);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "Rows";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(66, 411);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "Columns";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // arrDisplay
            // 
            this.arrDisplay.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.arrDisplay.FormattingEnabled = true;
            this.arrDisplay.ItemHeight = 14;
            this.arrDisplay.Location = new System.Drawing.Point(27, 12);
            this.arrDisplay.Name = "arrDisplay";
            this.arrDisplay.Size = new System.Drawing.Size(748, 312);
            this.arrDisplay.TabIndex = 4;
            this.arrDisplay.SelectedIndexChanged += new System.EventHandler(this.arrDisplay_SelectedIndexChanged);
            // 
            // textRows
            // 
            this.textRows.Cursor = System.Windows.Forms.Cursors.No;
            this.textRows.Font = new System.Drawing.Font("Bahnschrift", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textRows.Location = new System.Drawing.Point(27, 337);
            this.textRows.Multiline = true;
            this.textRows.Name = "textRows";
            this.textRows.PlaceholderText = "0";
            this.textRows.ReadOnly = true;
            this.textRows.Size = new System.Drawing.Size(33, 33);
            this.textRows.TabIndex = 5;
            this.textRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textRows.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textColumns
            // 
            this.textColumns.Cursor = System.Windows.Forms.Cursors.No;
            this.textColumns.Font = new System.Drawing.Font("Bahnschrift", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textColumns.Location = new System.Drawing.Point(27, 390);
            this.textColumns.Multiline = true;
            this.textColumns.Name = "textColumns";
            this.textColumns.PlaceholderText = "0";
            this.textColumns.ReadOnly = true;
            this.textColumns.Size = new System.Drawing.Size(33, 33);
            this.textColumns.TabIndex = 6;
            this.textColumns.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textColumns.TextChanged += new System.EventHandler(this.textColumns_TextChanged);
            // 
            // btnEXE
            // 
            this.btnEXE.Cursor = System.Windows.Forms.Cursors.AppStarting;
            this.btnEXE.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnEXE.Font = new System.Drawing.Font("Microsoft Uighur", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnEXE.Location = new System.Drawing.Point(689, 337);
            this.btnEXE.Name = "btnEXE";
            this.btnEXE.Size = new System.Drawing.Size(86, 33);
            this.btnEXE.TabIndex = 7;
            this.btnEXE.Text = "→";
            this.btnEXE.UseVisualStyleBackColor = true;
            this.btnEXE.Click += new System.EventHandler(this.btnEXE_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Help;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Microsoft Uighur", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(689, 388);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 35);
            this.button1.TabIndex = 8;
            this.button1.Text = "↺";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 449);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnEXE);
            this.Controls.Add(this.textColumns);
            this.Controls.Add(this.textRows);
            this.Controls.Add(this.arrDisplay);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbColumns);
            this.Controls.Add(this.tbRows);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "Times Tables";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.tbRows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbColumns)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TrackBar tbRows;
        private TrackBar tbColumns;
        private Label label1;
        private Label label2;
        private ListBox arrDisplay;
        private TextBox textRows;
        private TextBox textColumns;
        private Button btnEXE;
        private Button button1;
    }
}
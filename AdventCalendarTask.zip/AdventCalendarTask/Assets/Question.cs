﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdventCalendarTask.Assets
{
    internal class Question
    {
        public static List<Question> _questions = new() {
            new Question("What is the name of the Grinch's dog?", new[] {"Buddy", "Max", "Charlie", "Rex"}, 1),
            new Question("What is the name of the Grinch's dog?", new[] {"Buddy", "Max", "Charlie", "Rex"}, 1),
            new Question("Which reindeer is known for having a red nose?", new[] {"Comet", "Rudolph", "Dasher", "Blitzen"}, 1),
            new Question("What do people traditionally put on top of a Christmas tree?", new[] {"Santa", "Angel", "Star", "Snowflake"}, 2),
            new Question("In 'The Twelve Days of Christmas,' what did my true love give me on the fifth day?", new[] {"French Hens", "Golden Rings", "Drummers Drumming", "Turtle Doves"}, 1),
            new Question("What drink is often associated with Christmas?", new[] {"Mulled Wine", "Hot Chocolate", "Eggnog", "Apple Cider"}, 2),
            new Question("Where does Santa Claus live?", new[] {"The North Pole", "Lapland", "Greenland", "The South Pole"}, 0),
            new Question("What color is Santa’s suit?", new[] {"Green", "White", "Blue", "Red"}, 3),
            new Question("What is the name of the ballet associated with Christmas?", new[] {"Sleeping Beauty", "The Nutcracker", "Coppélia", "Swan Lake"}, 1),
            new Question("What Christmas decoration is made from evergreen branches?", new[] {"Wreath", "Ornaments", "Garland", "Tinsel"}, 0),
            new Question("What snack is often left out for Santa?", new[] {"Milk", "Cookies", "Candy Canes", "Carrots"}, 1),
            new Question("What is traditionally hidden inside a Christmas pudding?", new[] {"A nut", "A candy", "A bell", "A coin"}, 3),
            new Question("What are Santa's helpers called?", new[] {"Reindeer", "Fairies", "Elves", "Goblins"}, 2),
            new Question("What is the most popular Christmas plant?", new[] {"Mistletoe", "Holly", "Poinsettia", "Christmas Tree"}, 2),
            new Question("What do children traditionally hang by the fireplace?", new[] {"Gloves", "Scarves", "Stockings", "Hats"}, 2),
            new Question("What guided the Wise Men to Bethlehem?", new[] {"An Angel", "A Moonbeam", "A Star", "A Comet"}, 2),
            new Question("Which country is credited with starting the Christmas tree tradition?", new[] {"France", "Germany", "England", "USA"}, 1),
            new Question("What kind of tree is traditionally used for Christmas?", new[] {"Fir", "Cedar", "Oak", "Pine"}, 0),
            new Question("Who wrote 'A Christmas Carol'?", new[] {"Mark Twain", "J.R.R. Tolkien", "Jane Austen", "Charles Dickens"}, 3),
            new Question("What is the first name of Scrooge in 'A Christmas Carol'?", new[] {"Timothy", "Ebenezer", "Jacob", "Jonathan"}, 1),
            new Question("What is the name of the island in 'Rudolph the Red-Nosed Reindeer'?", new[] {"Island of Misfit Toys", "Toyland", "Isle of Misfits", "Misfit Land"}, 0),
            new Question("What does Santa say as he flies away?", new[] {"Merry Christmas to all!", "Ho, ho, ho!", "Goodnight to all!", "Happy New Year!"}, 0),
            new Question("What is the name of the famous snowman in 'Frozen'?", new[] {"Sven", "Olaf", "Kristoff", "Frosty"}, 1),
            new Question("What Christmas carol asks for figgy pudding?", new[] {"Deck the Halls", "Silent Night", "Jingle Bells", "We Wish You a Merry Christmas"}, 3),
        };

        public static List<Question> _trueFalse = new() {
            new Question("The first Christmas tree in America was erected in the White House.", new[] {"True", "False"}, 1),
            new Question("Santa Claus wears a green suit in traditional folklore.", new[] {"True", "False"}, 1),
            new Question("The song 'Jingle Bells' was originally written for Christmas.", new[] {"True", "False"}, 1),
            new Question("Rudolph the Red-Nosed Reindeer was created as part of a department store promotion.", new[] {"True", "False"}, 0),
            new Question("Mistletoe is considered a symbol of love and friendship.", new[] {"True", "False"}, 0),
            new Question("The tradition of caroling began in Germany.", new[] {"True", "False"}, 1),
            new Question("The movie 'Home Alone' is set during Thanksgiving.", new[] {"True", "False"}, 1),
            new Question("Christmas is celebrated on December 25th to mark the birth of Jesus Christ.", new[] {"True", "False"}, 0),
            new Question("The term 'Yuletide' comes from Norse traditions.", new[] {"True", "False"}, 0),
            new Question("The modern image of Santa Claus was popularized by Coca-Cola advertisements.", new[] {"True", "False"}, 0),
            new Question("Eggnog originated in Italy.", new[] {"True", "False"}, 1),
            new Question("In 'The Twelve Days of Christmas,' there are seven swans a-swimming.", new[] {"True", "False"}, 0),
            new Question("The character Ebenezer Scrooge was visited by three ghosts.", new[] {"True", "False"}, 0),
            new Question("The poinsettia plant is native to Mexico.", new[] {"True", "False"}, 0),
            new Question("Tinsel was originally made from silver.", new[] {"True", "False"}, 0),
            new Question("The first artificial Christmas trees were made of dyed goose feathers.", new[] {"True", "False"}, 0),
            new Question("The 'X' in 'Xmas' comes from the Greek letter Chi.", new[] {"True", "False"}, 0),
            new Question("In Italy, Christmas is called 'La Navidad.'", new[] {"True", "False"}, 1),
            new Question("The song 'White Christmas' is the best-selling single of all time.", new[] {"True", "False"}, 0),
            new Question("Saint Nicholas was a real historical figure.", new[] {"True", "False"}, 0),
            new Question("Boxing Day is celebrated on December 26th in many countries.", new[] {"True", "False"}, 0),
            new Question("Reindeer are found naturally in North America.", new[] {"True", "False"}, 1),
            new Question("The tradition of hanging stockings comes from the Netherlands.", new[] {"True", "False"}, 0),
            new Question("The word 'Noel' is derived from the Latin word for 'news.'", new[] {"True", "False"}, 0)
        };
        public string QuestionText { get; set; }
        public string[] Answers { get; set; }
        public int CorrectAnswerPosition { get; set; }

        public Question(string QuestionText, string[] Answers, int CorrectAnswerPosition) 
        {
            this.QuestionText = QuestionText;
            this.Answers = Answers;
            this.CorrectAnswerPosition = CorrectAnswerPosition;
        }
    }
}

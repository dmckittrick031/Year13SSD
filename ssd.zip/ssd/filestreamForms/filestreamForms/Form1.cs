using System.Text;

namespace filestreamForms
{
    public partial class Form1 : Form
    {
        static string filePath = @"U:\Documents\saveTo\formFile.txt";
        static byte[] byteData;
        static string? fileContent;
        static string? userFilePath;
        static FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
        static StreamReader sr = new(fs, leaveOpen:true);
        static StreamWriter sw = new(fs, leaveOpen:true);
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            using (sw)
            {
                sw.Write(txtToSave.Text+"\n");
            }
        }

        private void txtToSave_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtToSave.Clear();
        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new())
            {
                openFileDialog.InitialDirectory = @"c:/";
                openFileDialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (sr)
                    {
                        fileContent = sr.ReadToEnd();
                        txtToSave.Clear();
                        txtToSave.Text = fileContent;
                    }
                }
            }
        }
    }
}
﻿namespace RecursionTasks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a short sentence:");
            Console.Write("> ");
            string? userInString = Console.ReadLine();

            Console.Clear();
            foreach (char stringCharacter in userInString)
            {
                Console.WriteLine(stringCharacter);
            }
            Console.ReadLine();
        }
    }
}
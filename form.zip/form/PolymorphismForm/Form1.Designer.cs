﻿namespace PolymorphismForm
{
    partial class frmVoidMethods
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVoidMethods));
            this.txtOrderInput = new System.Windows.Forms.TextBox();
            this.toolTipOrderInput = new System.Windows.Forms.ToolTip(this.components);
            this.txtTotalOrder = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnSearchAllRecords = new System.Windows.Forms.Button();
            this.btnFindOrder = new System.Windows.Forms.Button();
            this.lstOrderDetails = new System.Windows.Forms.ListView();
            this.clmnOrderNum = new System.Windows.Forms.ColumnHeader();
            this.clmnCustomerName = new System.Windows.Forms.ColumnHeader();
            this.clmnSubtotal = new System.Windows.Forms.ColumnHeader();
            this.clmnVAT = new System.Windows.Forms.ColumnHeader();
            this.clmnTotal = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtOrderInput
            // 
            this.txtOrderInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtOrderInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOrderInput.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtOrderInput.ForeColor = System.Drawing.Color.White;
            this.txtOrderInput.Location = new System.Drawing.Point(12, 67);
            this.txtOrderInput.Multiline = true;
            this.txtOrderInput.Name = "txtOrderInput";
            this.txtOrderInput.Size = new System.Drawing.Size(460, 20);
            this.txtOrderInput.TabIndex = 1;
            this.toolTipOrderInput.SetToolTip(this.txtOrderInput, "Please enter your order number\r\n");
            this.txtOrderInput.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtTotalOrder
            // 
            this.txtTotalOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtTotalOrder.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotalOrder.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtTotalOrder.ForeColor = System.Drawing.Color.White;
            this.txtTotalOrder.Location = new System.Drawing.Point(12, 93);
            this.txtTotalOrder.Multiline = true;
            this.txtTotalOrder.Name = "txtTotalOrder";
            this.txtTotalOrder.ReadOnly = true;
            this.txtTotalOrder.Size = new System.Drawing.Size(460, 20);
            this.txtTotalOrder.TabIndex = 5;
            this.toolTipOrderInput.SetToolTip(this.txtTotalOrder, "Total number of orders");
            this.txtTotalOrder.TextChanged += new System.EventHandler(this.txtTotalOrder_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(12, 119);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(460, 20);
            this.textBox1.TabIndex = 6;
            this.toolTipOrderInput.SetToolTip(this.textBox1, "Total cost of orders");
            // 
            // btnSearchAllRecords
            // 
            this.btnSearchAllRecords.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnSearchAllRecords.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSearchAllRecords.FlatAppearance.BorderSize = 0;
            this.btnSearchAllRecords.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearchAllRecords.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSearchAllRecords.ForeColor = System.Drawing.Color.White;
            this.btnSearchAllRecords.Location = new System.Drawing.Point(12, 145);
            this.btnSearchAllRecords.Name = "btnSearchAllRecords";
            this.btnSearchAllRecords.Size = new System.Drawing.Size(224, 42);
            this.btnSearchAllRecords.TabIndex = 2;
            this.btnSearchAllRecords.Text = "Show All Records";
            this.btnSearchAllRecords.UseVisualStyleBackColor = false;
            this.btnSearchAllRecords.Click += new System.EventHandler(this.btnSearchAllRecords_Click);
            // 
            // btnFindOrder
            // 
            this.btnFindOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.btnFindOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnFindOrder.FlatAppearance.BorderSize = 0;
            this.btnFindOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFindOrder.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnFindOrder.ForeColor = System.Drawing.Color.White;
            this.btnFindOrder.Location = new System.Drawing.Point(242, 145);
            this.btnFindOrder.Name = "btnFindOrder";
            this.btnFindOrder.Size = new System.Drawing.Size(230, 42);
            this.btnFindOrder.TabIndex = 3;
            this.btnFindOrder.Text = "Find Order Details\r\n";
            this.btnFindOrder.UseVisualStyleBackColor = false;
            this.btnFindOrder.Click += new System.EventHandler(this.button2_Click);
            // 
            // lstOrderDetails
            // 
            this.lstOrderDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.lstOrderDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstOrderDetails.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmnOrderNum,
            this.clmnCustomerName,
            this.clmnSubtotal,
            this.clmnVAT,
            this.clmnTotal});
            this.lstOrderDetails.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lstOrderDetails.ForeColor = System.Drawing.Color.White;
            this.lstOrderDetails.GridLines = true;
            this.lstOrderDetails.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lstOrderDetails.Location = new System.Drawing.Point(12, 193);
            this.lstOrderDetails.Name = "lstOrderDetails";
            this.lstOrderDetails.Size = new System.Drawing.Size(460, 334);
            this.lstOrderDetails.TabIndex = 4;
            this.lstOrderDetails.UseCompatibleStateImageBehavior = false;
            this.lstOrderDetails.View = System.Windows.Forms.View.Details;
            this.lstOrderDetails.SelectedIndexChanged += new System.EventHandler(this.lstOrderDetails_SelectedIndexChanged);
            // 
            // clmnOrderNum
            // 
            this.clmnOrderNum.Text = "Order Number";
            this.clmnOrderNum.Width = 140;
            // 
            // clmnCustomerName
            // 
            this.clmnCustomerName.Text = "Customer Name";
            this.clmnCustomerName.Width = 140;
            // 
            // clmnSubtotal
            // 
            this.clmnSubtotal.Text = "Subtotal";
            // 
            // clmnVAT
            // 
            this.clmnVAT.Text = "VAT";
            // 
            // clmnTotal
            // 
            this.clmnTotal.Text = "Total";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(2, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(394, 58);
            this.label1.TabIndex = 0;
            this.label1.Text = "Gerry Fine Foods";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // frmVoidMethods
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(484, 539);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.txtTotalOrder);
            this.Controls.Add(this.lstOrderDetails);
            this.Controls.Add(this.btnFindOrder);
            this.Controls.Add(this.btnSearchAllRecords);
            this.Controls.Add(this.txtOrderInput);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmVoidMethods";
            this.Text = "Void Methods";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox txtOrderInput;
        private ToolTip toolTipOrderInput;
        private Button btnSearchAllRecords;
        private Button btnFindOrder;
        private ListView lstOrderDetails;
        private ColumnHeader clmnOrderNum;
        private ColumnHeader clmnCustomerName;
        private ColumnHeader clmnSubtotal;
        private ColumnHeader clmnVAT;
        private ColumnHeader clmnTotal;
        private Label label1;
        private TextBox txtTotalOrder;
        private TextBox textBox1;
    }
}
﻿namespace IComparable
{
    internal class Program
    {
        public class Student : IComparable<Student>
        {
            public string? Name {get; set;}
            public int Age {get; set;}
            public string? Gender {get; set;}

            public int CompareTo(Student other)
            {
                return this.Age.CompareTo(other.Age);
            }
        }
        static void Main(string[] args)
        {
            var studentList = new List<Student>
            {
                new Student {Name = "LeBron", Age = 48, Gender = "???"},
                new Student {Name = "Peter", Age = 16, Gender = "Male"},
                new Student {Name = "Harry", Age = 16, Gender = "Female"},
                new Student {Name = "David", Age = 16, Gender = "Male"},
                new Student {Name = "Josh", Age = 16, Gender = "Male"},
            };

            studentList.Sort();
            studentList.ForEach(student => Console.WriteLine($"Name = {student.Name}\tAge = {student.Age}\tGender = {student.Gender}"));
            Console.ReadLine();
        }
    }
}
